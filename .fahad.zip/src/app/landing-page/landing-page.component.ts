import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-landing-page',
  imports: [FormsModule, CommonModule, RouterLink],
  templateUrl: './landing-page.component.html',
  styleUrl: './landing-page.component.scss'
})
export class LandingPageComponent {

  singers: any[] = [
    {
      id: 1,
      image: "landing-page-assets/enrique.png",
      name: "Enrique Iglesias",
      cityName: "Manchester",
      date: "Oct 17- Oct 21",
      price: "$299.99",



      slotOne: {
        id: 20,
        singerImage: "choose-time/enrique-check",
        singerName: "Enrique Iglesias",
        concertDate: "03 June",
        concertDay: "SUN",
        concertTime: "08:00 PM",
        thePrice: "299.99",
        tickets: "198 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotTwo: {
        id: 21,
        singerImage: "choose-time/enrique-check",
        singerName: "Enrique Iglesias",
        concertDate: "03 June",
        concertDay: "SUN",
        thePrice: "299.99",
        concertTime: "10:00PM",
        tickets: "18 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },




      slotThree: {
        id: 22,
        singerImage: "choose-time/enrique-check",
        singerName: "Enrique Iglesias",
        concertDate: "04 June",
        thePrice: "299.99",
        concertDay: "MON",
        concertTime: "08:00 PM",
        tickets: "40 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotFour: {
        id: 23,
        singerImage: "choose-time/enrique-check",
        singerName: "Enrique Iglesias",
        thePrice: "299.99",
        concertDate: "04 June",
        concertDay: "MON",
        concertTime: "10:00 PM",
        tickets: "60 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotFive: {
        id: 24,
        singerImage: "choose-time/enrique-check",
        singerName: "Enrique Iglesias",
        thePrice: "299.99",
        concertDate: "05 June",
        concertDay: "TUES",
        concertTime: "08:00 PM",
        tickets: "70 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },



      slotSix: {
        id: 25,
        singerImage: "choose-time/enrique-check",
        singerName: "Enrique Iglesias",
        thePrice: "299.99",
        concertDate: "05 June",
        concertDay: "TUES",
        concertTime: "08:00 PM",
        tickets: "76 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotSeven: {
        id: 26,
        singerImage: "choose-time/enrique-check",
        singerName: "Enrique Iglesias",
        thePrice: "299.99",
        concertDate: "06 June",
        concertDay: "WED",
        concertTime: "08:00 PM",
        tickets: "98 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotEight: {
        id: 27,
        singerImage: "choose-time/enrique-check",
        singerName: "Enrique Iglesias",
        thePrice: "299.99",
        concertDate: "06 June",
        concertDay: "WED",
        concertTime: "10:00 PM",
        tickets: "102 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      }
    },

    {
      id: 2,
      image: "landing-page-assets/ariana.png",
      name: "Taylor Swift",
      cityName: "London",
      date: "Oct 22- Oct 24",
      price: "$199.99",
      isAdded: "false",

      slotOne: {
        id: 28,
        singerImage: "choose-time/tailorakka.png",
        singerName: "Taylor Swift",
        thePrice: "199.99",
        concertDate: "03 June",
        concertDay: "SUN",
        concertTime: "08:00 PM",
        tickets: "20 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotTwo: {
        id: 29,
        singerImage: "choose-time/tailorakka.png",
        singerName: "Taylor Swift",
        thePrice: "199.99",
        concertDate: "03 June",
        concertDay: "SUN",
        concertTime: "10:00PM",
        tickets: "18 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },




      slotThree: {
        id: 30,
        singerImage: "choose-time/tailorakka.png",
        singerName: "Taylor Swift",
        thePrice: "199.99",
        concertDate: "04 June",
        concertDay: "MON",
        concertTime: "08:00 PM",
        tickets: "40 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotFour: {
        id: 31,
        singerImage: "choose-time/tailorakka.png",
        singerName: "Taylor Swift",
        thePrice: "199.99",
        concertDate: "04 June",
        concertDay: "MON",
        concertTime: "10:00 PM",
        tickets: "60 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotFive: {
        id: 32,
        singerImage: "choose-time/tailorakka.png",
        singerName: "Taylor Swift",
        thePrice: "199.99",
        concertDate: "05 June",
        concertDay: "TUES",
        concertTime: "08:00 PM",
        tickets: "70 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },



      slotSix: {
        id: 33,
        singerImage: "choose-time/tailorakka.png",
        singerName: "Taylor Swift",
        thePrice: "199.99",
        concertDate: "05 June",
        concertDay: "TUES",
        concertTime: "08:00 PM",
        tickets: "76 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotSeven: {
        id: 34,
        singerImage: "choose-time/tailorakka.png",
        singerName: "Taylor Swift",
        thePrice: "199.99",
        concertDate: "06 June",
        concertDay: "WED",
        concertTime: "08:00 PM",
        tickets: "98 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotEight: {
        id: 35,
        singerImage: "choose-time/tailorakka.png",
        singerName: "Taylor Swift",
        thePrice: "199.99",
        concertDate: "06 June",
        concertDay: "WED",
        concertTime: "10:00 PM",
        tickets: "102 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      }


    },

    {
      id: 3,
      image: "landing-page-assets/justin.png",
      name: "Justin Bieber",
      cityName: "Manchester",
      date: "Oct 24- Oct 29",
      price: "$199.99",


      slotOne: {
        id: 36,
        singerImage: "choose-time/justin",
        singerName: "Justin Bieber",
        thePrice: "199.99",
        concertDate: "03 June",
        concertDay: "SUN",
        concertTime: "08:00 PM",
        tickets: "20 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotTwo: {
        id: 37,
        singerImage: "choose-time/justin",
        singerName: "Justin Bieber",
        thePrice: "199.99",
        concertDate: "03 June",
        concertDay: "SUN",
        concertTime: "10:00PM",
        tickets: "18 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },




      slotThree: {
        id: 38,
        singerImage: "choose-time/justin",
        singerName: "Justin Bieber",
        thePrice: "199.99",
        concertDate: "04 June",
        concertDay: "MON",
        concertTime: "08:00 PM",
        tickets: "40 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotFour: {
        id: 39,
        singerImage: "choose-time/justin",
        singerName: "Justin Bieber",
        thePrice: "199.99",
        concertDate: "04 June",
        concertDay: "MON",
        concertTime: "10:00 PM",
        tickets: "60 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotFive: {
        id: 40,
        singerImage: "choose-time/justin",
        singerName: "Justin Bieber",
        thePrice: "199.99",
        concertDate: "05 June",
        concertDay: "TUES",
        concertTime: "08:00 PM",
        tickets: "70 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },



      slotSix: {
        id: 41,
        singerImage: "choose-time/justin",
        singerName: "Justin Bieber",
        thePrice: "199.99",
        concertDate: "05 June",
        concertDay: "TUES",
        concertTime: "08:00 PM",
        tickets: "76 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotSeven: {
        id: 42,
        singerImage: "choose-time/justin",
        singerName: "Justin Bieber",
        thePrice: "199.99",
        concertDate: "06 June",
        concertDay: "WED",
        concertTime: "08:00 PM",
        tickets: "98 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotEight: {
        id: 43,
        singerImage: "choose-time/justin",
        singerName: "Justin Bieber",
        thePrice: "199.99",
        concertDate: "06 June",
        concertDay: "WED",
        concertTime: "10:00 PM",
        tickets: "102 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      }
    },


    {
      id: 4,
      image: "landing-page-assets/celen.png",
      name: "Celen Deon",
      cityName: "Bristol",
      date: "Oct 28- Oct 30",
      price: "$499.99",


      slotOne: {
        id: 44,
        singerImage: "choose-time/celen",
        singerName: "Celen Deon",
        thePrice: "499.99",
        concertDate: "03 June",
        concertDay: "SUN",
        concertTime: "08:00 PM",
        tickets: "20 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotTwo: {
        id: 45,
        singerImage: "choose-time/celen",
        singerName: "Celen Deon",
        thePrice: "499.99",
        concertDate: "03 June",
        concertDay: "SUN",
        concertTime: "10:00PM",
        tickets: "18 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },




      slotThree: {
        id: 46,
        singerImage: "choose-time/celen",
        singerName: "Celen Deon",
        thePrice: "499.99",
        concertDate: "04 June",
        concertDay: "MON",
        concertTime: "08:00 PM",
        tickets: "40 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotFour: {
        id: 47,
        singerImage: "choose-time/celen",
        singerName: "Celen Deon",
        thePrice: "499.99",
        concertDate: "04 June",
        concertDay: "MON",
        concertTime: "10:00 PM",
        tickets: "60 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotFive: {
        id: 48,
        singerImage: "choose-time/celen",
        singerName: "Celen Deon",
        thePrice: "499.99",
        concertDate: "05 June",
        concertDay: "TUES",
        concertTime: "08:00 PM",
        tickets: "70 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },



      slotSix: {
        id: 49,
        singerImage: "choose-time/celen",
        singerName: "Celen Deon",
        thePrice: "499.99",
        concertDate: "05 June",
        concertDay: "TUES",
        concertTime: "08:00 PM",
        tickets: "76 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotSeven: {
        id: 50,
        singerImage: "choose-time/celen",
        singerName: "Celen Deon",
        thePrice: "499.99",
        concertDate: "06 June",
        concertDay: "WED",
        concertTime: "08:00 PM",
        tickets: "98 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotEight: {
        id: 51,
        singerImage: "choose-time/celen",
        singerName: "Celen Deon",
        thePrice: "499.99",
        concertDate: "06 June",
        concertDay: "WED",
        concertTime: "10:00 PM",
        tickets: "102 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      }
    },


    {
      id: 5,

      image: "landing-page-assets/selena.png",
      name: "Selena Gomez",
      cityName: "London",
      date: "Oct 30- Oct 31",
      price: "$299.99",


      slotOne: {
        id: 52,
        singerImage: "choose-time/salena",
        singerName: "Selena Gomez",
        thePrice: "299.99",
        concertDate: "03 June",
        concertDay: "SUN",
        concertTime: "08:00 PM",
        tickets: "20 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotTwo: {
        id: 53,
        singerImage: "choose-time/salena",
        singerName: "Selena Gomez",
        thePrice: "299.99",
        concertDate: "03 June",
        concertDay: "SUN",
        concertTime: "10:00PM",
        tickets: "18 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },




      slotThree: {
        id: 54,
        singerImage: "choose-time/salena",
        singerName: "Selena Gomez",
        thePrice: "299.99",
        concertDate: "04 June",
        concertDay: "MON",
        concertTime: "08:00 PM",
        tickets: "40 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotFour: {
        id: 55,
        singerImage: "choose-time/salena",
        singerName: "Selena Gomez",
        thePrice: "299.99",
        concertDate: "04 June",
        concertDay: "MON",
        concertTime: "10:00 PM",
        tickets: "60 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotFive: {
        id: 56,
        singerImage: "choose-time/salena",
        singerName: "Selena Gomez",
        thePrice: "299.99",
        concertDate: "05 June",
        concertDay: "TUES",
        concertTime: "08:00 PM",
        tickets: "70 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },



      slotSix: {
        id: 57,
        singerImage: "choose-time/salena",
        singerName: "Selena Gomez",
        thePrice: "299.99",
        concertDate: "05 June",
        concertDay: "TUES",
        concertTime: "08:00 PM",
        tickets: "76 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotSeven: {
        id: 58,
        singerImage: "choose-time/salena",
        singerName: "Selena Gomez",
        thePrice: "299.99",
        concertDate: "06 June",
        concertDay: "WED",
        concertTime: "08:00 PM",
        tickets: "98 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotEight: {
        id: 59,
        singerImage: "choose-time/salena",
        singerName: "Selena Gomez",
        thePrice: "299.99",
        concertDate: "06 June",
        concertDay: "WED",
        concertTime: "10:00 PM",
        tickets: "102 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      }
    },


    {
      id: 6,
      image: "landing-page-assets/salena-gomes.png",
      name: "Ariana Grande",
      cityName: "Manchester",
      date: "Dec 01- Dec 05",
      price: "$499.99",



      slotOne: {
        id: 60,
        singerName: "Ariana Grande",
        singerImage: "choose-time/grande",
        thePrice: "499.99",
        concertDate: "03 June",
        concertDay: "SUN",
        concertTime: "08:00 PM",
        tickets: "20 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotTwo: {
        id: 61,
        singerName: "Ariana Grande",
        singerImage: "choose-time/grande",
        thePrice: "499.99",
        concertDate: "03 June",
        concertDay: "SUN",
        concertTime: "10:00PM",
        tickets: "18 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },




      slotThree: {
        id: 62,
        singerName: "Ariana Grande",
        singerImage: "choose-time/grande",
        thePrice: "499.99",
        concertDate: "04 June",
        concertDay: "MON",
        concertTime: "08:00 PM",
        tickets: "40 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotFour: {
        id: 63,
        singerName: "Ariana Grande",
        singerImage: "choose-time/grande",
        thePrice: "499.99",
        concertDate: "04 June",
        concertDay: "MON",
        concertTime: "10:00 PM",
        tickets: "60 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotFive: {
        id: 64,
        singerName: "Ariana Grande",
        singerImage: "choose-time/grande",
        thePrice: "499.99",
        concertDate: "05 June",
        concertDay: "TUES",
        concertTime: "08:00 PM",
        tickets: "70 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },



      slotSix: {
        id: 65,
        singerName: "Ariana Grande",
        singerImage: "choose-time/grande",
        thePrice: "499.99",
        concertDate: "05 June",
        concertDay: "TUES",
        concertTime: "08:00 PM",
        tickets: "76 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotSeven: {
        id: 66,
        singerName: "Ariana Grande",
        singerImage: "choose-time/grande",
        thePrice: "499.99",
        concertDate: "06 June",
        concertDay: "WED",
        concertTime: "08:00 PM",
        tickets: "98 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotEight: {
        id: 67,
        singerName: "Ariana Grande",
        singerImage: "choose-time/grande",
        thePrice: "499.99",
        concertDate: "06 June",
        concertDay: "WED",
        concertTime: "10:00 PM",
        tickets: "102 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      }
    },




  ]

  ngOnInit(): void { }

  addSinger(singer: any): void {


    let productDetail = JSON.parse(localStorage.getItem('productDetail') || '[]');
    productDetail.push(singer)
    localStorage.setItem("singer", JSON.stringify(productDetail))

    console.log(productDetail);
  }



  timeEndingEvents: any[] = [
    {
      id: 7,
      image: "landing-page-assets/time-tailor.png",
      name: "Taylor Swift",
      cityName: "London",
      date: "June 14 - June 19",
      price: "$799.99",
      days: "15D,",
      time: "08:45:03",

      slotOne: {
        id: 68,
        singerName: "Taylor Swift",
        singerImage: "choose-time/tailorakka.png",
        thePrice: "799.99",
        concertDate: "03 June",
        concertDay: "SUN",
        concertTime: "08:00 PM",
        tickets: "198 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotTwo: {
        id: 69,
        singerName: "Taylor Swift",
        singerImage: "choose-time/tailorakka.png",
        thePrice: "799.99",
        concertDate: "03 June",
        concertDay: "SUN",
        concertTime: "10:00PM",
        tickets: "18 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },




      slotThree: {
        id: 70,
        singerName: "Taylor Swift",
        singerImage: "choose-time/tailorakka.png",
        thePrice: "799.99",
        concertDate: "04 June",
        concertDay: "MON",
        concertTime: "08:00 PM",
        tickets: "40 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotFour: {
        id: 71,
        singerName: "Taylor Swift",
        singerImage: "choose-time/tailorakka.png",
        thePrice: "799.99",
        concertDate: "04 June",
        concertDay: "MON",
        concertTime: "10:00 PM",
        tickets: "60 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotFive: {
        id: 72,
        singerName: "Taylor Swift",
        singerImage: "choose-time/tailorakka.png",
        thePrice: "799.99",
        concertDate: "05 June",
        concertDay: "TUES",
        concertTime: "08:00 PM",
        tickets: "70 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },



      slotSix: {
        id: 73,
        singerName: "Taylor Swift",
        singerImage: "choose-time/tailorakka.png",
        thePrice: "799.99",
        concertDate: "05 June",
        concertDay: "TUES",
        concertTime: "08:00 PM",
        tickets: "76 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotSeven: {
        id: 74,
        singerName: "Taylor Swift",
        singerImage: "choose-time/tailorakka.png",
        thePrice: "799.99",
        concertDate: "06 June",
        concertDay: "WED",
        concertTime: "08:00 PM",
        tickets: "98 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotEight: {
        id: 75,
        singerImage: "choose-time/tailorakka.png",
        singerName: "Taylor Swift",
        thePrice: "799.99",
        concertDate: "06 June",
        concertDay: "WED",
        concertTime: "10:00 PM",
        tickets: "102 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      }
    },
    {
      id: 8,
      image: "landing-page-assets/time-ariana.png",
      name: "Ariana Grande",
      cityName: "Bristol",
      date: "June 15 - June 18",
      price: "$199.99",
      days: "14D, ",
      time: "11:34:03",


      slotOne: {
        id: 76,
        singerName: "Ariana Grande",
        singerImage: "choose-time/grande",
        thePrice: "199.99",
        concertDate: "03 June",
        concertDay: "SUN",
        concertTime: "08:00 PM",
        tickets: "20 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotTwo: {
        id: 77,
        singerName: "Ariana Grande",
        singerImage: "choose-time/grande",
        thePrice: "199.99",
        concertDate: "03 June",
        concertDay: "SUN",
        concertTime: "10:00PM",
        tickets: "18 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },




      slotThree: {
        id: 78,
        singerName: "Ariana Grande",
        singerImage: "choose-time/grande",
        thePrice: "199.99",
        concertDate: "04 June",
        concertDay: "MON",
        concertTime: "08:00 PM",
        tickets: "40 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotFour: {
        id: 79,
        singerName: "Ariana Grande",
        singerImage: "choose-time/grande",
        thePrice: "199.99",
        concertDate: "04 June",
        concertDay: "MON",
        concertTime: "10:00 PM",
        tickets: "60 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotFive: {
        id: 80,
        singerName: "Ariana Grande",
        thePrice: "199.99",
        singerImage: "choose-time/grande",
        concertDate: "05 June",
        concertDay: "TUES",
        concertTime: "08:00 PM",
        tickets: "70 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },



      slotSix: {
        id: 81,
        singerName: "Ariana Grande",
        singerImage: "choose-time/grande",
        thePrice: "199.99",
        concertDate: "05 June",
        concertDay: "TUES",
        concertTime: "08:00 PM",
        tickets: "76 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotSeven: {
        id: 82,
        singerName: "Ariana Grande",
        singerImage: "choose-time/grande",
        thePrice: "199.99",
        concertDate: "06 June",
        concertDay: "WED",
        concertTime: "08:00 PM",
        tickets: "98 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotEight: {
        id: 83,
        singerName: "Ariana Grande",
        singerImage: "choose-time/grande",
        thePrice: "199.99",
        concertDate: "06 June",
        concertDay: "WED",
        concertTime: "10:00 PM",
        tickets: "102 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      }

    },

    {
      id: 9,
      image: "landing-page-assets/time-adele.png",
      name: "Adele",
      cityName: "London",
      date: "June 19 - June 21",
      price: "$499.99",
      days: "12D, ",
      time: " 05:45:09",

      slotOne: {
        singerName: "Adele",
        singerImage: "choose-time/adele",
        thePrice: "499.99",
        concertDate: "03 June",
        concertDay: "SUN",
        concertTime: "08:00 PM",
        tickets: "20 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotTwo: {
        singerName: "Adele",
        singerImage: "choose-time/adele",
        thePrice: "499.99",
        concertDate: "03 June",
        concertDay: "SUN",
        concertTime: "10:00PM",
        tickets: "18 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },




      slotThree: {
        singerName: "Adele",
        singerImage: "choose-time/adele",
        thePrice: "499.99",
        concertDate: "04 June",
        concertDay: "MON",
        concertTime: "08:00 PM",
        tickets: "40 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotFour: {
        singerName: "Adele",
        singerImage: "choose-time/adele",
        thePrice: "499.99",
        concertDate: "04 June",
        concertDay: "MON",
        concertTime: "10:00 PM",
        tickets: "60 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotFive: {
        singerName: "Adele",
        singerImage: "choose-time/adele",
        thePrice: "499.99",
        concertDate: "05 June",
        concertDay: "TUES",
        concertTime: "08:00 PM",
        tickets: "70 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },



      slotSix: {
        singerName: "Adele",
        singerImage: "choose-time/adele",
        thePrice: "499.99",
        concertDate: "05 June",
        concertDay: "TUES",
        concertTime: "08:00 PM",
        tickets: "76 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotSeven: {
        singerName: "Adele",
        singerImage: "choose-time/adele",
        thePrice: "499.99",
        concertDate: "06 June",
        concertDay: "WED",
        concertTime: "08:00 PM",
        tickets: "98 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotEight: {
        singerName: "Adele",
        singerImage: "choose-time/adele",
        thePrice: "499.99",
        concertDate: "06 June",
        concertDay: "WED",
        concertTime: "10:00 PM",
        tickets: "102 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      }
    },

    {
      id: 10,
      image: "landing-page-assets/time-khalid.png",
      name: "Khalid",
      cityName: "London",
      date: "June 19 - June 21",
      price: "$499.99",
      days: "10D, ",
      time: " 06:32:18",
      slotOne: {
        singerName: "Khalid",
        singerImage: "choose-time/khalid",
        thePrice: "499.99",
        concertDate: "03 June",
        concertDay: "SUN",
        concertTime: "08:00 PM",
        tickets: "20 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotTwo: {
        singerName: "Khalid",
        singerImage: "choose-time/khalid",
        thePrice: "499.99",
        concertDate: "03 June",
        concertDay: "SUN",
        concertTime: "10:00PM",
        tickets: "18 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },




      slotThree: {
        singerName: "Khalid",
        singerImage: "choose-time/khalid",
        thePrice: "499.99",
        concertDate: "04 June",
        concertDay: "MON",
        concertTime: "08:00 PM",
        tickets: "40 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotFour: {
        singerName: "Khalid",
        singerImage: "choose-time/khalid",
        thePrice: "499.99",
        concertDate: "04 June",
        concertDay: "MON",
        concertTime: "10:00 PM",
        tickets: "60 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotFive: {
        singerName: "Khalid",
        singerImage: "choose-time/khalid",
        thePrice: "499.99",
        concertDate: "05 June",
        concertDay: "TUES",
        concertTime: "08:00 PM",
        tickets: "70 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },



      slotSix: {
        singerName: "Khalid",
        singerImage: "choose-time/khalid",
        thePrice: "499.99",
        concertDate: "05 June",
        concertDay: "TUES",
        concertTime: "08:00 PM",
        tickets: "76 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotSeven: {
        singerName: "Khalid",
        singerImage: "choose-time/khalid",
        thePrice: "499.99",
        concertDate: "06 June",
        concertDay: "WED",
        concertTime: "08:00 PM",
        tickets: "98 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      },


      slotEight: {
        singerName: "Khalid",
        singerImage: "choose-time/khalid",
        thePrice: "499.99",
        concertDate: "06 June",
        concertDay: "WED",
        concertTime: "10:00 PM",
        tickets: "102 Tickets Available!",
        quantity: 0,
        totalPrice: 0,
      }
    },

  ]

  timeEvent(timeEndingEvent: any): void {
    let timeEnding = JSON.parse(localStorage.getItem('timeEnding') || '[]');
    timeEnding.push(timeEndingEvent)
    localStorage.setItem("timeEndingEvent", JSON.stringify(timeEnding))

  }



  upcomingConcerts: any[] = [
    {
      id: 11,
      image: "landing-page-assets/edsheeran.png",
      name: "Ed Sheeran",
      cityName: "London",
      date: "sep 10 - Sep 13",
      day: "10 September 2024",

    },

    {
      id: 12,
      image: "landing-page-assets/shakira.png",
      name: "Shakira",
      cityName: "Manchester",
      date: "Sep14 - Sep19",
      day: "14 September 2024",
    },

    {
      id: 13,
      image: "landing-page-assets/pitbull.png",
      name: "Pitbull",
      cityName: "Bristol",
      date: "Nov02 - Nov04",
      day: "02 November 2024",
    },


    {
      id: 14,
      image: "landing-page-assets/ladygaga.png",
      name: "Lady Gaga",
      cityName: "London",
      date: "Sep24 - Sep29",
      day: "24 September 2024",
    },


    {
      id: 15,
      image: "landing-page-assets/omarion.png",
      name: "Omarion",
      cityName: "Bristol",
      date: "Nov02 - Nov04",
      day: "02 November 2024",
    },
  ]







}
