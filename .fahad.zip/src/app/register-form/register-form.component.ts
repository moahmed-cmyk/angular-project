import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, MinLengthValidator, ReactiveFormsModule, Validators } from '@angular/forms';
import { min } from 'rxjs';

@Component({
  selector: 'app-register-form',
  imports: [FormsModule,CommonModule,ReactiveFormsModule],
  templateUrl: './register-form.component.html',
  styleUrl: './register-form.component.scss'
})
export class RegisterFormComponent {

  userForm!: FormGroup
  isSubmitted:boolean=false
  age: string = ""
  formBuilder:FormBuilder=inject (FormBuilder)
  
  ngOnInit() {
    this.userForm = this.formBuilder.group({
      Name: [null, Validators.required],
      email: [null, [Validators.required,Validators.email]],
      password: [null, [Validators.required,Validators.minLength(8)]],
    })


  }

  

addDetail() {
 this.isSubmitted=true
  console.log(this.userForm);

}
}
