import { CommonModule } from '@angular/common';
import { Component, effect, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ColorServiceService } from '../service/color-service.service';

@Component({
  selector: 'app-header-two',
  imports: [FormsModule,CommonModule,RouterLink],
  templateUrl: './header-two.component.html',
  styleUrl: './header-two.component.scss'
})
export class HeaderTwoComponent {
  isActive: boolean = false;

  toggleNavbar() {
    this.isActive = !this.isActive;
  }


   service:ColorServiceService=inject(ColorServiceService)
   countEffect=effect(()=>{
     if(this.service.cartItemsCount()>0){
       alert("Your Booking is Added to Cart")
     }
   })
}
