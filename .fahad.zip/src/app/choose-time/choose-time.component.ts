import { CommonModule } from '@angular/common';
import { Component, inject, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ColorServiceService } from '../service/color-service.service';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-choose-time',
  imports: [FormsModule, CommonModule,RouterLink],
  templateUrl: './choose-time.component.html',
  styleUrl: './choose-time.component.scss'
})
export class ChooseTimeComponent implements OnInit {
  service: ColorServiceService = inject(ColorServiceService)

  savedItem: any[] = [];
  cartItemsCount: any;
  constructor() { }






  ngOnInit(): void {
    this.savedItem = JSON.parse(localStorage.getItem('singer') || '[]');
    console.log(this.savedItem);
  }

  addItem() {
    const newCount = this.service.cartItemsCount() + 1; 
    this.service.cartItemsCount.set(newCount); 
    localStorage.setItem('cartCount', newCount.toString()); 
  }



  setData(singer: any) {
  


    let productDetail = JSON.parse(localStorage.getItem('productDetail') || '[]');
    productDetail.push(singer)
    localStorage.setItem("singer", JSON.stringify(productDetail))

    console.log(productDetail);
  }


  sendInfo(singer: any) {


    let cart = JSON.parse(localStorage.getItem('cart') || '[]');
    cart.push(singer)
    localStorage.setItem("singer", JSON.stringify(cart))

    console.log(cart);
  }











  bookTicket(slotData: any) {
    if (slotData) {
      let existingSlots = JSON.parse(localStorage.getItem('slotData') || '[]');
  
      existingSlots.push(slotData);
  
      localStorage.setItem('slotData', JSON.stringify(existingSlots));
  
      console.log("Updated slotData in LocalStorage:", existingSlots);
      alert("Slot booked successfully!");
    } else {
      console.error("No slot data found.");
    }
  }
  





  










}
