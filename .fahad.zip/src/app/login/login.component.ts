import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-login',
  imports: [FormsModule, CommonModule, ReactiveFormsModule,RouterLink],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent {

  userForm!: FormGroup
  isSubmitted:boolean=false
  age: string = ""
  formBuilder:FormBuilder=inject (FormBuilder)
  
  ngOnInit() {
    this.userForm = this.formBuilder.group({
      age: [null, Validators.required],
      password: [null, [Validators.required]],
    })


  }

  

addDetail() {
 this.isSubmitted=true
  console.log(this.userForm);

}

}
