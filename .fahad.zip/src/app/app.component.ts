import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderTwoComponent } from "./header-two/header-two.component";

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, FormsModule, FooterComponent, HeaderTwoComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
}
